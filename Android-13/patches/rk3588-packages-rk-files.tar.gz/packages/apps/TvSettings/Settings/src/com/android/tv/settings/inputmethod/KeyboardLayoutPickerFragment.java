/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.tv.settings.inputmethod;

import android.content.Context;
import android.hardware.input.InputDeviceIdentifier;
import android.hardware.input.InputManager;
import android.hardware.input.InputManager.InputDeviceListener;
import android.hardware.input.KeyboardLayout;
import android.os.Bundle;
import androidx.preference.CheckBoxPreference;
import androidx.preference.Preference;
import androidx.preference.PreferenceScreen;
import android.view.InputDevice;

import com.android.internal.logging.nano.MetricsProto.MetricsEvent;
import com.android.tv.settings.R;
import com.android.tv.settings.SettingsPreferenceFragment;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class KeyboardLayoutPickerFragment extends SettingsPreferenceFragment
        implements InputDeviceListener {
    private InputDeviceIdentifier mInputDeviceIdentifier;
    private int mInputDeviceId = -1;
    private InputManager mIm;
    private KeyboardLayout[] mKeyboardLayouts;
    private HashMap<CheckBoxPreference, KeyboardLayout> mPreferenceMap = new HashMap<>();

    /**
     * Intent extra: The input device descriptor of the keyboard whose keyboard
     * layout is to be changed.
     */
    public static final String EXTRA_INPUT_DEVICE_IDENTIFIER = "input_device_identifier";

    /**
     * @return New fragment instance
     */
    public static KeyboardLayoutPickerFragment newInstance() {
        return new KeyboardLayoutPickerFragment();
    }

    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);

        mInputDeviceIdentifier = getActivity().getIntent().getParcelableExtra(
                EXTRA_INPUT_DEVICE_IDENTIFIER);
        if (mInputDeviceIdentifier == null) {
            getActivity().finish();
        }


        mIm = (InputManager) getContext().getSystemService(Context.INPUT_SERVICE);
        mKeyboardLayouts = mIm.getKeyboardLayoutsForInputDevice(mInputDeviceIdentifier);
        Arrays.sort(mKeyboardLayouts);
        setPreferenceScreen(createPreferenceHierarchy());
    }

    @Override
    public void onResume() {
        super.onResume();

        mIm.registerInputDeviceListener(this, null);

        InputDevice inputDevice =
                mIm.getInputDeviceByDescriptor(mInputDeviceIdentifier.getDescriptor());
        if (inputDevice == null) {
            getActivity().finish();
            return;
        }
        mInputDeviceId = inputDevice.getId();

        updateCheckedState();
    }

    @Override
    public void onPause() {
        mIm.unregisterInputDeviceListener(this);
        mInputDeviceId = -1;

        super.onPause();
    }

    @Override
    public boolean onPreferenceTreeClick(Preference preference) {
        if (preference instanceof CheckBoxPreference) {
            CheckBoxPreference checkboxPref = (CheckBoxPreference)preference;
            KeyboardLayout layout = mPreferenceMap.get(checkboxPref);
            if (layout != null) {
                boolean checked = checkboxPref.isChecked();
                if (checked) {
                    mIm.addKeyboardLayoutForInputDevice(mInputDeviceIdentifier,
                            layout.getDescriptor());
                } else {
                    mIm.removeKeyboardLayoutForInputDevice(mInputDeviceIdentifier,
                            layout.getDescriptor());
                }
                return true;
            }
        }
        return super.onPreferenceTreeClick(preference);
    }

    @Override
    public void onInputDeviceAdded(int deviceId) {
    }

    @Override
    public void onInputDeviceChanged(int deviceId) {
        if (mInputDeviceId >= 0 && deviceId == mInputDeviceId) {
            updateCheckedState();
        }
    }

    @Override
    public void onInputDeviceRemoved(int deviceId) {
        if (mInputDeviceId >= 0 && deviceId == mInputDeviceId) {
            getActivity().finish();
        }
    }

    @Override
    public void onCreatePreferences(Bundle bundle, String s) {
    }

    private PreferenceScreen createPreferenceHierarchy() {
        PreferenceScreen root = getPreferenceManager().createPreferenceScreen(getPreferenceManager().getContext());

        root.setTitle(getString(R.string.keyboard_layout_picker_title));

        for (KeyboardLayout layout : mKeyboardLayouts) {
            CheckBoxPreference pref = new CheckBoxPreference(getContext());
            pref.setLayoutResource(R.layout.leanback_preference);// default use framework/base/core/res/res/layout/preference.xml ,now use frameworks/support/leanback-preference/src/main/res/layout/leanback_preference.xml
            pref.setTitle(layout.getLabel());
            pref.setSummary(layout.getCollection());
            root.addPreference(pref);
            mPreferenceMap.put(pref, layout);
        }
        return root;
    }

    private void updateCheckedState() {
        String[] enabledKeyboardLayouts = mIm.getEnabledKeyboardLayoutsForInputDevice(
                mInputDeviceIdentifier);
        Arrays.sort(enabledKeyboardLayouts);

        for (Map.Entry<CheckBoxPreference, KeyboardLayout> entry : mPreferenceMap.entrySet()) {
            entry.getKey().setChecked(Arrays.binarySearch(enabledKeyboardLayouts,
                    entry.getValue().getDescriptor()) >= 0);
        }
    }
}
